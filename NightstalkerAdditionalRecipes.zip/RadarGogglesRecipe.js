ServerEvents.recipes(event => {
    event.shaped(
        Item.of('create_radar_mobile_radars:radar_goggles'),
        [
            '   ',
            'BAC',
            '   '
        ],
        {
            A: 'create:goggles',
            B: 'create_radar:monitor',
            C: 'create_radar:data_link',
        }
    )
})