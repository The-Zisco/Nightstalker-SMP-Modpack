ServerEvents.recipes(event => {
    event.remove({ output: 'aeroengineering:airborne_radar' })
})