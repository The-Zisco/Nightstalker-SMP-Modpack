ServerEvents.recipes(event => {
    event.shaped(
        Item.of('create_radar:guided_fuze'),
        [
            ' C ',
            ' B ',
            ' A '
        ],
        {
            A: 'minecraft:redstone',
            B: 'createbigcannons:inertia_fuze',
            C: 'create_radar:data_link',
        }
    )
})