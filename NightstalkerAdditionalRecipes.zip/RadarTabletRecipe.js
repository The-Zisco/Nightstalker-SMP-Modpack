ServerEvents.recipes(event => {
    event.shaped(
        Item.of('create_radar_mobile_radars:mobile_radar_tablet'),
        [
            ' C ',
            ' B ',
            ' A '
        ],
        {
            A: 'computercraft:pocket_computer_normal',
            B: 'create_radar:monitor',
            C: 'create_radar:data_link',
        }
    )
})