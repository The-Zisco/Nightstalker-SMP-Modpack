ServerEvents.recipes(event => {
    event.shaped(
        Item.of('create_radar:radar_warning_receiver'), // arg 1: output
        [
            'AAA',
            'ABA', // arg 2: the shape (array of strings)
            'ACA'
        ],
        {
            A: 'minecraft:iron_ingot',
            B: 'create:transmitter',  //arg 3: the mapping object
            C: 'create_radar:data_link'
        }
    )
})