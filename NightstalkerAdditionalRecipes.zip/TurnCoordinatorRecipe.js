ServerEvents.recipes(event => {
    event.shapeless(
        Item.of('dashpanelsextra:turn_coordinator'),
        [
            'dashpanelsextra:attitude_indicator',
        ]
    )
})