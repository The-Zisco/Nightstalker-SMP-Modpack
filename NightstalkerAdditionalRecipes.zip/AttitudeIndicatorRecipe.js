ServerEvents.recipes(event => {
    event.stonecutting('dashpanelsextra:attitude_indicator', 'simulated:gimbal_sensor')
})