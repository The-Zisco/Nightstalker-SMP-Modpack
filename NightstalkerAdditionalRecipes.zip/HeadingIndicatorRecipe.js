ServerEvents.recipes(event => {
    event.stonecutting('dashpanelsextra:heading_indicator', 'minecraft:compass')
})