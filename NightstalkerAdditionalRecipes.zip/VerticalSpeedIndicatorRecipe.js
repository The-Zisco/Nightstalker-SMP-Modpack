ServerEvents.recipes(event => {
    event.shapeless(
        Item.of('dashpanelsextra:vertical_speed_indicator'),
        [
            'dashpanelsextra:airspeed_indicator',
        ]
    )
})