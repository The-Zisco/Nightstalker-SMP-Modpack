ServerEvents.recipes(event => {
    event.stonecutting('dashpanelsextra:voice_detector', 'simpleradio:microphone')
})