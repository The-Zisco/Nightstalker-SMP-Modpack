ServerEvents.recipes(event => {
    event.remove({ output: 'aeroengineering:missile_assembly_station' })
})