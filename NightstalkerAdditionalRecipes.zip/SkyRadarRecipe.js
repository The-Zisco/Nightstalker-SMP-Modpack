ServerEvents.recipes(event => {
    event.shaped(
        Item.of('create_radar:sky_radar'),
        [
            ' D ',
            ' B ',
            'ACA'
        ],
        {
            A: 'create:electron_tube',
            B: 'create_radar:radar_bearing',
            C: 'createbigcannons:cannon_mount',
            D: 'create:transmitter'
        }
    )
})