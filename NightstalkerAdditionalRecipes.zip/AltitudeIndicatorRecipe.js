ServerEvents.recipes(event => {
    event.stonecutting('dashpanelsextra:altitude_indicator', 'simulated:altitude_sensor')
})