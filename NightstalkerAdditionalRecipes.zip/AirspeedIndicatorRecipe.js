ServerEvents.recipes(event => {
    event.stonecutting('dashpanelsextra:airspeed_indicator', 'simulated:velocity_sensor')
})