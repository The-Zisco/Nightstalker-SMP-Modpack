ServerEvents.recipes(event => {
    event.shaped(
        Item.of('create_radar:t_pitch'),
        [
            '   ',
            'ABA',
            '   '
        ],
        {
            A: 'create:precision_mechanism',
            B: 'create:gearbox',
        }
    )
})